import streamlit as st
import pandas as pd
import plotly.express as px
from PIL import Image
from wordcloud import WordCloud
from textblob import TextBlob
from sklearn.feature_extraction.text import TfidfVectorizer
import nltk
from nltk.tokenize import word_tokenize
from nltk import pos_tag
from collections import Counter
from itertools import combinations
import networkx as nx
import matplotlib.pyplot as plt
import plotly.graph_objects as go
from flask import Flask, send_file, render_template

nltk.download('punkt')
nltk.download('averaged_perceptron_tagger')

# Funções auxiliares e carregamento de dados
@st.cache_data
def load_data():
    df = pd.read_csv("C:/Users/Fernanda Costa/OneDrive - Universidade de Aveiro/Desktop/projeto_ICD/dashboard_ICD/scopus.csv")
    return df

def create_chart(df, x, y, chart_type="bar", title="Gráfico", **kwargs):
    def define_periodo(ano):
        try:
            ano = int(ano)
            if ano < 2019:
                return "Antes da COVID-19"
            elif 2019 <= ano <= 2023:
                return "Durante a COVID-19"
            else:
                return "Depois da COVID-19"
        except ValueError:
            return "Ano inválido"

    df['Periodo'] = df[x].apply(define_periodo)
    cores = {
        "Antes da COVID-19": "#FFA07A",
        "Durante a COVID-19": "#FF4500",
        "Depois da COVID-19": "#FFD700"
    }

    if chart_type == "bar":
        fig = px.bar(
            df,
            x=x,
            y=y,
            color='Periodo',
            color_discrete_map=cores,
            title=title,
            **kwargs
        )
    elif chart_type == "scatter":
        fig = px.scatter(df, x=x, y=y, title=title, **kwargs)
    elif chart_type == "line":
        fig = px.line(df, x=x, y=y, title=title, **kwargs)
    else:
        raise ValueError("Tipo de gráfico não suportado.")
    return fig



def inicio(df):
    # Título do Dashboard
    st.markdown("<h1 style='text-align: center; color: #FFA500;'>Perceção da IA no Mercado de Trabalho</h1>", unsafe_allow_html=True)
    st.write("""Bem-vindo ao Dashboard de Análise Bibliométrica e de Conteúdo! Este painel interativo permite explorar tanto dados bibliométricos quanto análises de conteúdo textual.""")

    # Imagem
    imagem = "C:/Users/Fernanda Costa/OneDrive - Universidade de Aveiro/Desktop/projeto_ICD/dashboard_ICD/ia_mercado_trabalho_linha70.jpeg"
    st.image(imagem, caption="Imagem da IA no contexto de emprego", use_container_width=True)

    # Botão de download do CSV
    st.download_button(
        label="Baixar CSV",
        data=df.to_csv(index=False),  # Converter o DataFrame para CSV
        file_name="scopus.csv",
        mime="text/csv"
    )
    
    # Tabs com os conteúdos existentes
    tab1, tab2, tab3 = st.tabs(["Apresentação", "Palavras-chave", "Questão de Investigação"])

    with tab1:
        st.subheader("Apresentação")
        st.write("""  
        Trabalho académico, cujo objetivo assenta na perceção da IA no mercado de trabalho por tempo e delimitações territoriais. 
        Para isso, é mostrado, ao longo desta aplicação, vários meios interativos que permitem realizar uma análise a partir de gráficos, tabelas e mapas.
        """)

    with tab2:
        st.subheader("**Palavras-chave**")
        st.write("Artificial Intelligence, Labor Market, Employment, Technology")

    with tab3:
        st.subheader("Questão de Investigação")
        st.write("""  
        Como é que o equilíbrio entre a criação e a destruição de empregos causada pela IA varia entre diferentes países?
        """)
        st.markdown("**Subquestões:**")
        st.markdown("i. Quais as alterações do conteúdo ao longo do tempo?")
        st.markdown("ii. Será que a pandemia COVID-19 afetou a abordagem desta temática?")

    with tab2:
        st.subheader("**Palavras-chave**")
        st.write("Artificial Intelligence, Labor Market, Employment, Technology")

    with tab3:
        st.subheader("Questão de Investigação")
        st.write("""  
        Como é que o equilíbrio entre a criação e a destruição de empregos causada pela IA varia entre diferentes países?
        """)
        st.markdown("**Subquestões:**")
        st.markdown("i. Quais as alterações do conteúdo ao longo do tempo?")
        st.markdown("ii. Será que a pandemia COVID-19 afetou a abordagem desta temática?")
    
    tab1, tab2 = st.tabs(["Nuvem de Palavras", "Palavras mais Relevantes"])
    # Separando o código em duas abas: tab1 e tab2
    with tab1:
        # Nuvem de palavras
        st.subheader("Nuvem de Palavras")
        text = ' '.join(df['clean_Abstract'].dropna())
        wordcloud = generate_wordcloud(text)
        st.image(wordcloud.to_array(), use_container_width=True, caption="Nuvem de palavras mais frequentes nos abstracts")

    with tab2:
        # Gráfico de barras das palavras mais relevantes
        st.subheader("Palavras mais Relevantes")
        palavras = word_tokenize(text)
        frequencia = pd.Series(palavras).value_counts().head(10)
        frequencia_df = frequencia.reset_index()
        frequencia_df.columns = ['Palavra', 'Frequência']

        fig = create_chart(frequencia_df, x='Palavra', y='Frequência', chart_type="bar", title="Palavras mais Relevantes")
        st.plotly_chart(fig)

def generate_wordcloud(text):
    return WordCloud(width=800, height=400, max_words=100, background_color='white', colormap='Oranges').generate(text)

def plot_network(G):
    # Obter as posições dos nós usando o layout 'spring' do networkx
    pos = nx.spring_layout(G, seed=42)
    
    # Criar listas de nós e arestas
    edges = list(G.edges())
    edge_x = []
    edge_y = []
    for edge in edges:
        x0, y0 = pos[edge[0]]
        x1, y1 = pos[edge[1]]
        edge_x.append(x0)
        edge_y.append(y0)
        edge_x.append(x1)
        edge_y.append(y1)

    edge_trace = go.Scatter(
        x=edge_x, y=edge_y,
        line=dict(width=1, color='gray'),
        hoverinfo='none',
        mode='lines'
    )

    node_x = []
    node_y = []
    for node in G.nodes():
        x, y = pos[node]
        node_x.append(x)
        node_y.append(y)

    node_trace = go.Scatter(
        x=node_x, y=node_y,
        mode='markers',
        hoverinfo='text',
        marker=dict(
            showscale=True,
            colorscale='YlOrRd',
            size=10,
            colorbar=dict(
                thickness=15,
                title='Node Connections',
                xanchor='left',
                titleside='right'
            )
        )
    )

    # Adicionar rótulos aos nós
    node_text = []
    for node in G.nodes():
        node_text.append(node)
    node_trace.marker.color = [len(list(G.neighbors(node))) for node in G.nodes()]
    node_trace.text = node_text

    # Criar o layout da rede
    fig = go.Figure(data=[edge_trace, node_trace],
                    layout=go.Layout(
                        title='Rede de Colaborações entre Autores',
                        titlefont_size=16,
                        showlegend=False,
                        hovermode='closest',
                        xaxis=dict(showgrid=False, zeroline=False),
                        yaxis=dict(showgrid=False, zeroline=False)
                    ))

    st.plotly_chart(fig)

def define_periodo(year):
    try:
        year = int(year)  # Converte para inteiro
        if year < 2020:
            return "Antes da COVID-19"
        elif 2020 <= year <= 2021:
            return "Durante a COVID-19"
        else:
            return "Depois da COVID-19"
    except (ValueError, TypeError) as e:
        return "Indefinido"  # Valor padrão em caso de erro

# Definindo a estrutura principal do Streamlit
def main():
    st.set_page_config(page_title="Perceção da IA no Mercado de Trabalho", page_icon="🤖", layout="centered")
    
    # Barra lateral
    st.sidebar.title("Menu de Análises")
    options = ["Início", "Análise de Bibliometria", "Análise de Conteúdo"]
    menu = st.sidebar.radio("Escolha a análise", options)

    # Carregar dados
    df = load_data()
    if df is None:
        st.error("Erro ao carregar os dados. Verifique o arquivo.")
        st.stop()

    # Selecionar número de artigos
    total_articles = len(df)
    num_articles = st.sidebar.slider("Selecione o número de artigos a analisar:", min_value=10, max_value=total_articles, value=100, step=10)
    df = df.head(num_articles)
    
    # Chamando a função 'inicio' no menu principal
    if menu == "Início":
        inicio(df)

    if menu == "Análise de Bibliometria":
        st.header("Análise Bibliométrica")
        st.write("Explore os dados bibliométricos das publicações académicas.")

        anos = st.sidebar.multiselect("Selecione os anos", df['Year'].unique(), default=df['Year'].unique(), key="anos_bibliometria")
        df_filtered = df[df['Year'].isin(anos)]

        tab1, tab2, tab3, tab4, tab5, tab6, tab7 = st.tabs(["Exploração de Dados", "Localização", "Autores Influentes", "Frequência de Artigos por País", "Colaborações entre Autores", "Publicações por Autor", "Periodicidade"])

        with tab1:
            st.subheader("Amostra de dados carregados:")
            st.dataframe(df_filtered.head())

            st.write("Distribuição por Ano:")
            year_count = df_filtered['Year'].value_counts().reset_index()
            year_count.columns = ['Year', 'Count']
            fig = create_chart(year_count, x='Year', y='Count', chart_type="bar", title="Publicações por Ano")
            st.plotly_chart(fig)

        with tab2:
            st.subheader("Distribuição geográfica das publicações:")
            mapa_imagem = "C:/Users/Fernanda Costa/OneDrive - Universidade de Aveiro/Desktop/projeto_ICD/dashboard_ICD/mapa_localizacoes_documentos_linha236.png"
            st.image(mapa_imagem, caption="Mapa Geográfico das Publicações", use_container_width=True)
            
            # Tabela de Localizações por País
            st.subheader("Tabela de localizações por país")
            if 'Pais' in df.columns:
                country_location_counts = df_filtered['Pais'].value_counts().reset_index()
                country_location_counts.columns = ['Pais', 'Publicações']
                st.write(country_location_counts)
            else:
                st.warning("Não há informações sobre países disponíveis nos dados para exibir a tabela.")
            
        with tab3:
            st.write("Influência dos Autores por Citações e Artigos")
            # Calcular as citações por autor (simulando uma coluna de citações - ajuste conforme sua base de dados)
            df_filtered['Citation_Count'] = df_filtered['Cited by'].fillna(0)
            # Alteração no código de agregação para contar os artigos por autor
            author_influence = df_filtered.groupby('Authors').agg({'Citation_Count': 'sum'}).reset_index()
            author_influence['Total Artigos'] = df_filtered.groupby('Authors')['Authors'].transform('count').reset_index(drop=True)
            author_influence.columns = ['Author', 'Total Citações', 'Total Artigos']
            
            # Gráfico de barras de autores mais influentes por citações
            st.subheader("Gráfico de barras dos autores mais influentes por citações:")
            author_influence_sorted = author_influence.sort_values(by='Total Citações', ascending=False).head(10)
            fig_bar = create_chart(author_influence_sorted, x='Author', y='Total Citações', chart_type="bar", title="Autores mais Influentes por Citações")
            st.plotly_chart(fig_bar)
            
            # Gráfico de dispersão
            st.subheader("Gráfico de dispersão dos autores mais influentes por citações:")
            fig_scatter = px.scatter(
                author_influence,
                x='Total Artigos',
                y='Total Citações',
                hover_name='Author',
                hover_data={'Author': True, 'Total Artigos': True, 'Total Citações': True},
                color_discrete_sequence=['#FFA500']  # Definindo a cor laranja (código hexadecimal #FFA500)
            )
            st.plotly_chart(fig_scatter)

            # Tabela de influência dos autores por citações
            st.subheader("Tabela de influência dos autores por citações:")
            author_influence_sorted = author_influence.sort_values(by='Total Citações', ascending=False).head(10)
            st.write(author_influence_sorted)

        with tab4:
            st.subheader("Distribuição geográfica das publicações categorizado por frequência:")
            mapa_imagem = "C:/Users/Fernanda Costa/OneDrive - Universidade de Aveiro/Desktop/projeto_ICD/dashboard_ICD/mapa_frequencia_documentos_pais_linha282.png"
            st.image(mapa_imagem, caption="Mapa Geográfico das Publicações", use_container_width=True)
            
            st.subheader("Frequência de artigos por país:")
            country_counts_df = df_filtered['Pais'].value_counts().reset_index()
            country_counts_df.columns = ['Country', 'Publications']
            st.write(country_counts_df)
            
            st.subheader("RELACIONADO À ANÁLISE DE CONTEÚDO TEMOS:")
            st.subheader("Análise de palavras por país")
            # Filtrando países únicos no dataframe
            paises_unicos = sorted(df_filtered['Pais'].unique())
            pais_selecionado = st.selectbox("Selecione um país para analisar palavras:", paises_unicos)

            if pais_selecionado:
                textos_pais = ' '.join(df_filtered[df_filtered['Pais'] == pais_selecionado]['clean_Abstract'].dropna())
                wordcloud_pais = generate_wordcloud(textos_pais)
                st.image(wordcloud_pais.to_array(), caption=f"Nuvem de Palavras para {pais_selecionado}", use_container_width=True)

            # Adicionando uma barra de pesquisa para selecionar o país
            pais_selecionado = st.selectbox(
                "Escolha um país para visualizar as palavras mais frequentes:",
                options=paises_unicos,
                index=0  # Define o primeiro país como padrão
            )
            # Filtrar o dataframe pelo país selecionado
            df_pais = df_filtered[df_filtered['Pais'] == pais_selecionado]

            # Gerar a contagem de palavras mais frequentes
            palavras = ' '.join(df_pais['Author Keywords'])
            palavras_frequentes = Counter(palavras.split()).most_common(10)
            palavras_df = pd.DataFrame(palavras_frequentes, columns=['Palavra', 'Frequência'])

            # Gráfico de barras para palavras mais frequentes
            st.subheader(f"Palavras mais frequentes no país: {pais_selecionado}")
            fig_palavras = px.bar(
                palavras_df,
                x='Palavra',
                y='Frequência',
                title=f"Distribuição de Palavras no {pais_selecionado}",
                color='Palavra',  # Cores diferentes para cada palavra
                text='Frequência'  # Exibir a frequência no gráfico
            )
            fig_palavras.update_layout(xaxis_title="Palavras", yaxis_title="Frequência")
            st.plotly_chart(fig_palavras)
            
        with tab5:
            st.write("Colaborações entre autores")
            st.subheader("Rede de colaborações entre autores:")
            # Gerar a rede de colaborações entre autores (já com base no código fornecido anteriormente)
            G = nx.Graph()

            # Criando as arestas para a rede
            for authors in df_filtered['Authors'].dropna():
                author_list = authors.split(";")
                if len(author_list) > 1:
                    for comb in combinations(author_list, 2):
                        G.add_edge(comb[0], comb[1])

            # Chamar a função para desenhar a rede
            plot_network(G)
        
        with tab6:
            st.write("Publicações por autor")
            st.subheader("Gráfico de barras das publicações por autor")
            
            # Contagem de publicações por autor
            publications_per_author = df_filtered['Authors'].dropna().str.split(";").explode().value_counts().reset_index()
            publications_per_author.columns = ['Author', 'Publications Count']
            
            # Gráfico de barras
            fig_author_bar = create_chart(publications_per_author, x='Author', y='Publications Count', chart_type="bar", title="Publicações por Autor")
            st.plotly_chart(fig_author_bar)

            # Tabela de frequências de publicações por autor
            st.subheader("Tabela de frequência de publicações por autor:")
            st.write(publications_per_author)
        
        publicacoes_por_ano = df['Year'].value_counts().sort_index()

        # Criar a aba 'Periodicidade' (Tab7)
        with tab7:
            st.write("Periodicidade das publicações")
            # Agrupamento dos dados por períodos definidos
            df_filtered['Periodo'] = df_filtered['Year'].apply(define_periodo)
            period_counts = df_filtered['Periodo'].value_counts().reset_index()
            period_counts.columns = ['Periodo', 'Publicações']
            period_counts = period_counts.sort_values(by='Publicações', ascending=False)

            # Gráfico de barras (com cor personalizada)
            st.subheader("Gráfico de barras por períodos:")
            fig_bar_period = px.bar(
                period_counts,
                x='Periodo',
                y='Publicações',
                color='Periodo',  # Cor definida pelos períodos
                color_discrete_map={
                    "Antes da COVID-19": "#FFA07A",  # Cor laranja clara
                    "Durante a COVID-19": "#FF4500",  # Cor laranja intensa
                    "Depois da COVID-19": "#FFD700"   # Cor amarela
                },
                title="Distribuição de Publicações por Períodos"
            )
            st.plotly_chart(fig_bar_period)

            # Gráfico de dispersão (com cor personalizada)
            st.subheader("Gráfico de dispersão de publicações por período:")
            fig_scatter_period = px.scatter(
                df_filtered,
                x='Year',
                y='Citation_Count',  # Simulando uma métrica de citação
                color='Periodo',  # Cor definida pelos períodos
                color_discrete_map={
                    "Antes da COVID-19": "#FFA07A",
                    "Durante a COVID-19": "#FF4500",
                    "Depois da COVID-19": "#FFD700"
                },
                title="Dispersão de Publicações por Período",
                hover_data={'Year': True, 'Citation_Count': True}
            )
            st.plotly_chart(fig_scatter_period)

    elif menu == "Análise de Conteúdo":
        st.header("Análise de Conteúdo dos Abstracts")
        st.write("Analise palavras mais comuns, sentimentos e tópicos dos abstracts.")

        tab1, tab2, tab3, tab4 = st.tabs(["Palavras mais comuns", "Análise de Sentimentos", "POS", "TF-IDF"])

        with tab1:
            st.write("Selecione os anos para gerar a nuvem de palavras:")
            anos_selecionados = st.multiselect("Filtrar por anos", df['Year'].unique(), default=df['Year'].unique(), key="nuvem_anos")
            df_filtrado_wordcloud = df[df['Year'].isin(anos_selecionados)]
            text_filtrado = ' '.join(df_filtrado_wordcloud['clean_Abstract'].dropna())
            if text_filtrado.strip():
                wordcloud_filtrada = generate_wordcloud(text_filtrado)
                st.image(wordcloud_filtrada.to_array(), use_container_width=True)
            else:
                st.warning("Não há dados para os anos selecionados.")

        with tab2:
            st.write("Selecione os anos para a análise de sentimentos:")
            anos_sentimentos = st.multiselect("Filtrar por anos", df['Year'].unique(), default=df['Year'].unique(), key="sentimentos_anos")
            df_sentimentos_filtrado = df[df['Year'].isin(anos_sentimentos)]

            if not df_sentimentos_filtrado.empty:
                # Calcular polaridade dos sentimentos
                sentiments = df_sentimentos_filtrado['clean_Abstract'].dropna().apply(lambda x: TextBlob(str(x)).sentiment.polarity)
                df_sentimentos_filtrado['Sentiment_Category'] = sentiments.apply(
                    lambda s: 'Positivo' if s > 0 else 'Negativo' if s < 0 else 'Neutro'
                )

                # Contar categorias de sentimentos
                sentiment_counts = df_sentimentos_filtrado['Sentiment_Category'].value_counts().reset_index()
                sentiment_counts.columns = ['Sentiment', 'Count']

                # Criar o gráfico de sentimentos
                sentiment_fig = create_chart(sentiment_counts, x='Sentiment', y='Count', chart_type="bar", title="Distribuição de Sentimentos")
                st.plotly_chart(sentiment_fig)
            else:
                st.warning("Não há dados para os anos selecionados.")

        with tab3:
            pos_data = df['clean_Abstract'].dropna().apply(lambda x: pos_tag(word_tokenize(str(x))))
            pos_tags = [tag for sublist in pos_data for _, tag in sublist]
            pos_counts = pd.Series(pos_tags).value_counts().reset_index()
            pos_counts.columns = ['POS_Tag', 'Count']
            fig = create_chart(pos_counts.head(15), x='POS_Tag', y='Count', chart_type="bar", title="Classes Gramaticais (POS)")
            st.plotly_chart(fig)

        with tab4:
            tfidf_vectorizer = TfidfVectorizer(stop_words='english')
            tfidf_matrix = tfidf_vectorizer.fit_transform(df['clean_Abstract'].dropna())
            feature_names = tfidf_vectorizer.get_feature_names_out()
            tfidf_values = tfidf_matrix.sum(axis=0).A1
            tfidf_data = pd.DataFrame({'Term': feature_names, 'TF-IDF': tfidf_values})
            tfidf_data = tfidf_data.sort_values(by='TF-IDF', ascending=False).head(20)
            fig = create_chart(tfidf_data, x='TF-IDF', y='Term', chart_type="bar", title="Termos mais Relevantes pelo TF-IDF")
            st.plotly_chart(fig)

if __name__ == "__main__":
    main()